using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class resdume : MonoBehaviour
{
    public static bool gameispast = false;
    public GameObject pasetmanue;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (gameispast)
            {
                resume();
            }
            else
            {
                past();
            }
        }

    }
    public void resume()
    {
        pasetmanue.SetActive(false);
        Time.timeScale = 1f;
        gameispast = false;
    }
    void past()
    {
        pasetmanue.SetActive(true);
        Time.timeScale = 0f;
        gameispast = true;
    }
    
}
