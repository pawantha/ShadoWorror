using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class helthcount : MonoBehaviour
{
    public Image[] live;
    public int liferemaine;
    private Animator anim;
    private Rigidbody2D rb;
    public GameObject endui;
    public GameObject winui;
    public GameObject heth;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    public void loselife()
    {
        
        liferemaine--;
        live[liferemaine].enabled = false;

        if (liferemaine == 0)
        {
            anim.SetTrigger("die");
            sounds.playersound("died");
            endui.SetActive(true);
        }
        Hurt();
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.transform.tag == "enemy")
        {
            loselife();
        }
        if(other.transform.tag == "end")
        {
            gameend();
        }
        if (other.transform.tag == "helth")
        {
            Destroy(other.gameObject);
            helth();
            
        }
    }
    void Hurt()
    {    
         anim.SetTrigger("hurt");
        sounds.playersound("hit");


    }
    void gameend()
    {
        winui.SetActive(true);
        sounds.playersound("win");
    }
    void helth()
    {
        if (liferemaine != 2)
        {
            liferemaine++;
            live[liferemaine].enabled = true;
            anim.SetTrigger("attack");
        }
        
    }

}
