using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class coinepick : MonoBehaviour
{
    private float coine = 0;
    public TextMeshProUGUI textcoines;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.transform.tag == "coines")
        {
            coine++;
            
            textcoines.text = coine.ToString();
            Destroy(other.gameObject);
        }
    }
}
