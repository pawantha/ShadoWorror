using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sounds : MonoBehaviour
{
    [SerializeField] public static AudioClip jumpsound,hitesound,diedsound, coinsound, heltsound,win;
    static AudioSource audioscr;
    // Start is called before the first frame update
    void Start()
    {
        jumpsound = Resources.Load<AudioClip>("jump");
        hitesound = Resources.Load<AudioClip>("hurt");
        diedsound = Resources.Load<AudioClip>("dei");
        coinsound = Resources.Load<AudioClip>("coin");
        heltsound = Resources.Load<AudioClip>("helth");
        win = Resources.Load<AudioClip>("sb_indreams");
        audioscr = GetComponent<AudioSource> ();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
   public static void playersound(string clip)
    {
        switch (clip)
        {
            case "jump":
                audioscr.PlayOneShot(jumpsound);
                break;
            case "hit":
                audioscr.PlayOneShot(hitesound);
                break;
            case "died":
                audioscr.PlayOneShot(diedsound);
                break;
            case "coin":
                audioscr.PlayOneShot(coinsound);
                break;
            case "healt":
                audioscr.PlayOneShot(heltsound);
                break;
            case "win":
                audioscr.PlayOneShot(heltsound);
                break;
        }
    }
}
